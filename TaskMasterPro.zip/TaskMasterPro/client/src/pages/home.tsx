import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { TaskModal } from "@/components/TaskModal";
import { DeleteConfirmModal } from "@/components/DeleteConfirmModal";
import { 
  Plus, 
  Search, 
  LogOut, 
  User, 
  List, 
  Clock, 
  CheckCircle, 
  Calendar,
  Edit,
  Trash2
} from "lucide-react";
import type { Task } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    retry: false,
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, task }: { id: number; task: Partial<Task> }) => {
      await apiRequest("PATCH", `/api/tasks/${id}`, task);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setDeleteModalOpen(false);
      setTaskToDelete(null);
      toast({
        title: "Success",
        description: "Task deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive",
      });
    },
  });

  const handleTaskToggle = (task: Task) => {
    updateTaskMutation.mutate({
      id: task.id,
      task: { completed: !task.completed }
    });
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setTaskModalOpen(true);
  };

  const handleDeleteTask = (task: Task) => {
    setTaskToDelete(task);
    setDeleteModalOpen(true);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || 
                         (statusFilter === "completed" && task.completed) ||
                         (statusFilter === "pending" && !task.completed);
    
    const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const taskStats = {
    total: tasks.length,
    completed: tasks.filter(t => t.completed).length,
    pending: tasks.filter(t => !t.completed).length,
    overdue: tasks.filter(t => !t.completed && t.dueDate && new Date(t.dueDate) < new Date()).length,
  };

  const priorityCounts = {
    high: tasks.filter(t => t.priority === "high").length,
    medium: tasks.filter(t => t.priority === "medium").length,
    low: tasks.filter(t => t.priority === "low").length,
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-amber-100 text-amber-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityDotColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-500";
      case "medium": return "bg-amber-500";
      case "low": return "bg-green-500";
      default: return "bg-gray-500";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <>
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <div className="w-4 h-4 bg-white rounded-sm"></div>
              </div>
              <h1 className="text-xl font-bold text-gray-900">TaskFlow</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 pl-10 pr-4 py-2"
                />
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                  <User className="h-4 w-4 text-gray-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : user?.email}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="lg:w-80">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-gray-900">Task Overview</h2>
                  <Button
                    onClick={() => {
                      setEditingTask(null);
                      setTaskModalOpen(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Task
                  </Button>
                </div>
                
                {/* Task Stats */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{taskStats.total}</div>
                    <div className="text-sm text-blue-600">Total Tasks</div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{taskStats.completed}</div>
                    <div className="text-sm text-green-600">Completed</div>
                  </div>
                  <div className="bg-amber-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-amber-600">{taskStats.pending}</div>
                    <div className="text-sm text-amber-600">Pending</div>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">{taskStats.overdue}</div>
                    <div className="text-sm text-red-600">Overdue</div>
                  </div>
                </div>
                
                {/* Filter Options */}
                <div className="space-y-4">
                  <h3 className="text-sm font-medium text-gray-900 uppercase tracking-wide">Filters</h3>
                  
                  <div className="space-y-2">
                    <Button
                      variant={statusFilter === "all" ? "secondary" : "ghost"}
                      className="w-full justify-between"
                      onClick={() => setStatusFilter("all")}
                    >
                      <span className="flex items-center space-x-3">
                        <List className="h-4 w-4 text-gray-500" />
                        <span>All Tasks</span>
                      </span>
                      <span className="text-sm text-gray-500">{taskStats.total}</span>
                    </Button>
                    
                    <Button
                      variant={statusFilter === "pending" ? "secondary" : "ghost"}
                      className="w-full justify-between"
                      onClick={() => setStatusFilter("pending")}
                    >
                      <span className="flex items-center space-x-3">
                        <Clock className="h-4 w-4 text-amber-500" />
                        <span>Pending</span>
                      </span>
                      <span className="text-sm text-gray-500">{taskStats.pending}</span>
                    </Button>
                    
                    <Button
                      variant={statusFilter === "completed" ? "secondary" : "ghost"}
                      className="w-full justify-between"
                      onClick={() => setStatusFilter("completed")}
                    >
                      <span className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span>Completed</span>
                      </span>
                      <span className="text-sm text-gray-500">{taskStats.completed}</span>
                    </Button>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-200">
                    <h4 className="text-sm font-medium text-gray-900 mb-3">Priority</h4>
                    <div className="space-y-2">
                      <Button
                        variant={priorityFilter === "high" ? "secondary" : "ghost"}
                        className="w-full justify-between"
                        onClick={() => setPriorityFilter(priorityFilter === "high" ? "all" : "high")}
                      >
                        <span className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                          <span>High Priority</span>
                        </span>
                        <span className="text-sm text-gray-500">{priorityCounts.high}</span>
                      </Button>
                      
                      <Button
                        variant={priorityFilter === "medium" ? "secondary" : "ghost"}
                        className="w-full justify-between"
                        onClick={() => setPriorityFilter(priorityFilter === "medium" ? "all" : "medium")}
                      >
                        <span className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                          <span>Medium Priority</span>
                        </span>
                        <span className="text-sm text-gray-500">{priorityCounts.medium}</span>
                      </Button>
                      
                      <Button
                        variant={priorityFilter === "low" ? "secondary" : "ghost"}
                        className="w-full justify-between"
                        onClick={() => setPriorityFilter(priorityFilter === "low" ? "all" : "low")}
                      >
                        <span className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          <span>Low Priority</span>
                        </span>
                        <span className="text-sm text-gray-500">{priorityCounts.low}</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </aside>

          {/* Task List */}
          <div className="flex-1">
            <Card>
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-gray-900">Tasks</h2>
                </div>
              </div>
              
              <div className="divide-y divide-gray-200">
                {filteredTasks.length === 0 ? (
                  <div className="p-12 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <List className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks found</h3>
                    <p className="text-gray-600 mb-4">
                      {tasks.length === 0
                        ? "Get started by creating your first task."
                        : "No tasks match your current filters."}
                    </p>
                    <Button
                      onClick={() => {
                        setEditingTask(null);
                        setTaskModalOpen(true);
                      }}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Create Task
                    </Button>
                  </div>
                ) : (
                  filteredTasks.map((task) => (
                    <div key={task.id} className="p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0 mt-1">
                          <Checkbox
                            checked={task.completed}
                            onCheckedChange={() => handleTaskToggle(task)}
                          />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className={`text-lg font-medium ${task.completed ? 'line-through opacity-60' : ''} text-gray-900`}>
                              {task.title}
                            </h3>
                            <div className="flex items-center space-x-2">
                              <Badge className={getPriorityColor(task.priority)}>
                                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
                              </Badge>
                              <Badge className={task.completed ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"}>
                                {task.completed ? "Completed" : 
                                 (task.dueDate && new Date(task.dueDate) < new Date() ? "Overdue" : "Pending")}
                              </Badge>
                            </div>
                          </div>
                          
                          {task.description && (
                            <p className={`text-gray-600 mb-3 ${task.completed ? 'line-through opacity-60' : ''}`}>
                              {task.description}
                            </p>
                          )}
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            {task.dueDate && (
                              <span className="flex items-center space-x-1">
                                <Calendar className="h-4 w-4" />
                                <span className={task.completed ? '' : (new Date(task.dueDate) < new Date() ? 'text-red-600 font-medium' : '')}>
                                  {task.completed ? 'Completed' : 'Due'}: {formatDate(task.dueDate)}
                                </span>
                              </span>
                            )}
                            {task.createdAt && (
                              <span className="flex items-center space-x-1">
                                <Clock className="h-4 w-4" />
                                <span>Created: {formatDate(task.createdAt)}</span>
                              </span>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex-shrink-0">
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditTask(task)}
                              className="text-gray-400 hover:text-blue-600"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteTask(task)}
                              className="text-gray-400 hover:text-red-600"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>
        </div>
      </main>

      <TaskModal
        open={taskModalOpen}
        onOpenChange={setTaskModalOpen}
        task={editingTask}
      />

      <DeleteConfirmModal
        open={deleteModalOpen}
        onOpenChange={setDeleteModalOpen}
        task={taskToDelete}
        onConfirm={() => {
          if (taskToDelete) {
            deleteTaskMutation.mutate(taskToDelete.id);
          }
        }}
        isLoading={deleteTaskMutation.isPending}
      />
    </>
  );
}
