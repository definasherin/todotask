import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Filter, Plus } from "lucide-react";

export default function Landing() {
  const handleGetStarted = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <div className="max-w-md w-full mx-4">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <div className="w-4 h-4 bg-blue-600 rounded-sm"></div>
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">TaskFlow</h1>
          <p className="text-xl text-gray-600 mb-8">
            Organize your tasks efficiently with our modern task management system
          </p>
          
          <div className="grid grid-cols-1 gap-4 mb-8">
            <Card>
              <CardContent className="flex items-center space-x-3 p-4">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Plus className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-left">
                  <h3 className="font-medium text-gray-900">Create & Manage</h3>
                  <p className="text-sm text-gray-600">Add, edit, and organize your tasks</p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="flex items-center space-x-3 p-4">
                <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                  <Filter className="w-5 h-5 text-amber-600" />
                </div>
                <div className="text-left">
                  <h3 className="font-medium text-gray-900">Filter & Sort</h3>
                  <p className="text-sm text-gray-600">Filter by priority and status</p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="flex items-center space-x-3 p-4">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div className="text-left">
                  <h3 className="font-medium text-gray-900">Track Progress</h3>
                  <p className="text-sm text-gray-600">Monitor your productivity</p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Button 
            onClick={handleGetStarted}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-lg font-medium transition-colors"
          >
            Get Started
          </Button>
        </div>
      </div>
    </div>
  );
}
