import { useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface AuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AuthModal({ open, onOpenChange }: AuthModalProps) {
  // Since we're using Replit Auth, we immediately redirect to the auth flow
  // when the modal opens instead of showing a custom form
  useEffect(() => {
    if (open) {
      // Small delay to show the modal briefly before redirecting
      const timer = setTimeout(() => {
        window.location.href = "/api/login";
      }, 100);
      
      return () => clearTimeout(timer);
    }
  }, [open]);

  const handleGetStarted = () => {
    window.location.href = "/api/login";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-sm"></div>
              </div>
            </div>
            <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
              Welcome to TaskFlow
            </DialogTitle>
            <p className="text-gray-600">Manage your tasks efficiently</p>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-4">
                  Sign in to access your tasks and start organizing your workflow.
                </p>
                <Button 
                  onClick={handleGetStarted}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium transition-colors"
                >
                  Continue with Authentication
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
